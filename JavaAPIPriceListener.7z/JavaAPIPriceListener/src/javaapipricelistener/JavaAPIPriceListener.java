package javaapipricelistener;

import com.fxcm.external.api.transport.FXCMLoginProperties;
import com.fxcm.external.api.transport.GatewayFactory;
import com.fxcm.external.api.transport.IGateway;
import com.fxcm.external.api.transport.listeners.IGenericMessageListener;
import com.fxcm.external.api.transport.listeners.IStatusMessageListener;
import com.fxcm.fix.SubscriptionRequestTypeFactory;
import com.fxcm.fix.pretrade.MarketDataRequest;
import com.fxcm.fix.pretrade.MarketDataSnapshot;
import com.fxcm.fix.pretrade.TradingSessionStatus;
import com.fxcm.messaging.ISessionStatus;
import com.fxcm.messaging.ITransportable;

public class JavaAPIPriceListener implements IGenericMessageListener, IStatusMessageListener {

	private final IGateway gateway;
	private FXCMLoginProperties loginProperties;
	private TradingSessionStatus tradingSessionStatus;

        private String mUsername;
        private String mPassword;
        private String mUrl = "http://www.fxcorporate.com/Hosts.jsp";
        private String mConnection = "Demo";
        public String symbol = "EUR/USD";

    
	public static void main(String[] aArgs) throws Exception {
            
        if (aArgs.length < 2) {
            System.out.println("must supply arguments: username, password, connection (default=Demo), url (default=http://www.fxcorporate.com/Hosts.jsp), symbol (default=EUR/USD)");
            return;
        }
            
		JavaAPIPriceListener japl = new JavaAPIPriceListener();
		japl.mUsername = aArgs[0];
		japl.mPassword = aArgs[1];
                if (aArgs.length > 2)
                    japl.mConnection = aArgs[2];
                if (aArgs.length > 3)
                    japl.mUrl = aArgs[3];
                if (aArgs.length > 4)
                    japl.symbol = aArgs[4];
                
		japl.loadConfig();
		japl.login();
		System.in.read();
		japl.logout(); // to make the example simple this may throw a "socket closed" error on disconnect
	}

	public JavaAPIPriceListener() {
		this.gateway = GatewayFactory.createGateway();
	}

	public boolean loadConfig() {
		this.loginProperties = new FXCMLoginProperties(
						this.mUsername,
						this.mPassword,
						this.mConnection,
						this.mUrl);
		return true;
	}

	public boolean login() throws Exception {
		this.gateway.registerGenericMessageListener(this);
		this.gateway.registerStatusMessageListener(this);
		this.gateway.login(this.loginProperties);
		this.gateway.requestTradingSessionStatus(); // account remembers subscription status between logins and will start stremaing automatically after requesting trading session status
		return this.gateway.isConnected();
	}

	public void subscribe() {
		MarketDataRequest mdr = new MarketDataRequest();
		mdr.addRelatedSymbol(this.tradingSessionStatus.getSecurity(symbol)); // as trading session status is required to properly build a subscription request, call it only after it is received
		mdr.setSubscriptionRequestType(SubscriptionRequestTypeFactory.SUBSCRIBE);
		mdr.setMDEntryTypeSet(MarketDataRequest.MDENTRYTYPESET_ALL);
		try {
			this.gateway.sendMessage(mdr);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void logout() throws Exception {
		this.gateway.logout();
	}

	@Override
	public void messageArrived(ITransportable it) {
		if (it instanceof MarketDataSnapshot) {
			this.messageArrived((MarketDataSnapshot) it);
		} else if (it instanceof TradingSessionStatus) {
			this.messageArrived((TradingSessionStatus) it);
		}
	}

	public void messageArrived(MarketDataSnapshot mds) {
		System.out.println(mds.toString());
	}
	
	public void messageArrived(TradingSessionStatus tss) {
		System.out.println(tss);
		this.tradingSessionStatus = tss;
		this.subscribe(); // call subscribe only after we get trading session status
	}

	@Override
	public void messageArrived(ISessionStatus iss) {
		// not required for this example
	}
}
